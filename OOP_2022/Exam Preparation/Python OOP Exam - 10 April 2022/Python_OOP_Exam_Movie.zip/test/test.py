

from unittest import TestCase, main

from project.movie import Movie


class TestsMovieClass(TestCase):

    def setUp(self) -> None:

        #Movie(self, name: str, year: int, rating: float)
        self.movie = Movie("Avatar", 2020, 8.60)

    def test_name_init(self):
        self.assertEqual("Avatar", self.movie.name)
        self.assertEqual(2020, self.movie.year)
        self.assertEqual(8.6, self.movie.rating)
        self.assertEqual([], self.movie.actors)

    def test_error_init(self):
        with self.assertRaises(ValueError) as ve:
            self.movie.name = ''
        self.assertEqual("Name cannot be an empty string!", str(ve.exception))
        with self.assertRaises(ValueError) as ve:
            self.movie.year = 120
        self.assertEqual("Year is not valid!", str(ve.exception))

    def test_add_actor(self):
        self.movie.add_actor("Maria")
        self.movie.add_actor("Georgi")

        self.assertEqual(["Maria", "Georgi"], self.movie.actors)
        name = "Maria"
        result = self.movie.add_actor(name)
        self.assertEqual(f"{name} is already added in the list of actors!", result)

    def test_gt_working(self):
        movie1 = self.movie
        movie2 = Movie("Hulk", 1999, 8)
        movie3 = Movie("Bad", 1999, 3)
        result = movie1.__gt__(movie2)
        self.assertEqual(f'"{movie1.name}" is better than "{movie2.name}"', result)

        result = movie3.__gt__(movie1)
        self.assertEqual(f'"{movie1.name}" is better than "{movie3.name}"', result)

    def test_repr__(self):
        self.movie.actors.append("test")
        self.movie.actors.append("test1")

        exe = str(self.movie)

        act = f"Name: {self.movie.name}\n" \
               f"Year of Release: {self.movie.year}\n" \
               f"Rating: {self.movie.rating:.2f}\n" \
               f"Cast: {', '.join(self.movie.actors)}"
        self.assertEqual(exe, act)


if __name__ == "__main__":
    main()