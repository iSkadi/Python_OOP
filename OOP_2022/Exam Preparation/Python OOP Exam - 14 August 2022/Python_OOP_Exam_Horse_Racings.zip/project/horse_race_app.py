from project.horse_race import HorseRace
from project.horse_specification.appaloosa import Appaloosa
from project.horse_specification.thoroughbred import Thoroughbred
from project.jockey import Jockey
from project.validators.validators import Validators


class HorseRaceApp:

    def __init__(self):
        self.horses = []
        self.jockeys = []
        self.horse_races = []

    def add_horse(self, horse_type: str, horse_name: str, horse_speed: int):
        # valid_types = ["Appaloosa", "Thoroughbred"]
        if not Validators.name_exist(horse_name, self.horses):
            if horse_type == "Appaloosa":
                self.horses.append(Appaloosa(horse_name, horse_speed))
                return f"{horse_type} horse {horse_name} is added."
            if horse_type == "Thoroughbred":
                self.horses.append(Thoroughbred(horse_name, horse_speed))
                return f"{horse_type} horse {horse_name} is added."
        else:
            raise Exception(f"Horse {horse_name} has been already added!")

    def add_jockey(self, jockey_name: str, age: int):
        if Validators.name_exist(jockey_name, self.jockeys):
            raise Exception(f"Jockey {jockey_name} has been already added!")
        self.jockeys.append(Jockey(jockey_name, age))
        return f'Jockey {jockey_name} is added.'

    def create_horse_race(self, race_type: str):
        if Validators.race_exist(race_type, self.horse_races):
            raise Exception(f"Race {race_type} has been already created!")
        self.horse_races.append(HorseRace(race_type))
        return f"Race {race_type} is created."

    def add_horse_to_jockey(self, jockey_name: str, horse_type: str):
        if not Validators.name_exist(jockey_name, self.jockeys):
            raise Exception(f"Jockey {jockey_name} could not be found!")

        horse = Validators.have_free_horse(horse_type, self.horses)

        if not horse:
            raise Exception(f"Horse breed {horse_type} could not be found!")
        j = Validators.name_exist(jockey_name, self.jockeys)
        if j.horse:
            return f"Jockey {jockey_name} already has a horse."
        j.horse = horse
        horse.is_taken = True
        return f"Jockey {jockey_name} will ride the horse {horse.name}."

    def add_jockey_to_horse_race(self, race_type: str, jockey_name: str):
        race = Validators.race_exist(race_type, self.horse_races)
        if not race:
            raise Exception(f"Race {race_type} could not be found!")
        jockey = Validators.name_exist(jockey_name, self.jockeys)
        if not jockey:
            raise Exception(f"Jockey {jockey_name} could not be found!")
        if not jockey.horse:
            raise Exception(f"Jockey {jockey_name} cannot race without a horse!")

        if Validators.name_exist(jockey_name, race.jockeys):
            return f"Jockey {jockey_name} has been already added to the {race_type} race."

        race.jockeys.append(jockey)

        return f"Jockey {jockey_name} added to the {race_type} race."

    def start_horse_race(self, race_type: str):
        race = Validators.race_exist(race_type, self.horse_races)
        if not race:
            raise Exception(f"Race {race_type} could not be found!")
        if len(race.jockeys) < 2:
            raise Exception(f"Horse race {race_type} needs at least two participants!")

        winner_speed = 0
        winner_jockey = ""
        winner_horse = ''
        for jockey in race.jockeys:
            if jockey.horse.speed > winner_speed:
                winner_speed = jockey.horse.speed
                winner_jockey = jockey.name
                winner_horse = jockey.horse.name

        return f"The winner of the {race_type} race, with a speed of {winner_speed}km/h is {winner_jockey}! Winner's horse: {winner_horse}."





