
class Validators:

    @staticmethod
    def name_exist(current_name, collection):
        for name in collection:
            if name.name == current_name:
                return name
        return None

    @staticmethod
    def race_exist(current_name, collection):
        for race in collection:
            if race.race_type == current_name:
                return race
        return None

    @staticmethod
    def have_free_horse(type_horse, collection):
        for horse in reversed(collection):
            if horse.__class__.__name__ == type_horse:
                if horse.is_taken is False:
                    return horse
        return None



