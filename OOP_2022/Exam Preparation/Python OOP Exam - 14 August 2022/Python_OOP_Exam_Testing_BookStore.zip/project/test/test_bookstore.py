from project.bookstore import Bookstore
from unittest import TestCase, main


class TestBookstore(TestCase):
    def setUp(self) -> None:
        self.bookstore = Bookstore(10)
        self.bookstore.availability_in_store_by_book_titles = {"Book1": 2, "Book2": 2}

    def test_init(self):
        bookstore = Bookstore(10)
        bookstore.availability_in_store_by_book_titles = {"Book1": 2, "Book2": 2}
        self.assertEqual(10, bookstore.books_limit)
        self.assertEqual({"Book1": 2, "Book2": 2}, bookstore.availability_in_store_by_book_titles)
        self.assertEqual(0, bookstore.total_sold_books)

    def test_books_limit_error(self):

        with self.assertRaises(ValueError) as ve:
            self.bookstore.books_limit = 0
        self.assertEqual(f"Books limit of 0 is not valid", str(ve.exception))
        with self.assertRaises(ValueError) as ve:
            self.bookstore.books_limit = -1
        self.assertEqual(f"Books limit of -1 is not valid", str(ve.exception))

    def test_len(self):

        result = self.bookstore.__len__()
        self.assertEqual(4, result)
        self.bookstore.receive_book("NOva", 6)
        result2 = self.bookstore.__len__()
        self.assertEqual(10, result2)

    def test_receive_book_exception(self):
        self.bookstore.books_limit = 5
        self.bookstore.availability_in_store_by_book_titles = {"Book1": 2, "Book2": 2}
        # >
        with self.assertRaises(Exception) as ex:
            self.bookstore.receive_book("Book1", 2)
        self.assertEqual("Books limit is reached. Cannot receive more books!", str(ex.exception))

    def test_book_title(self):
        self.bookstore.availability_in_store_by_book_titles = {"Book1": 2, "Book2": 2}
        result = self.bookstore.receive_book("Book3", 1)
        self.assertEqual('1 copies of Book3 are available in the bookstore.', result)
        self.assertEqual({'Book1': 2, 'Book2': 2, 'Book3': 1}, self.bookstore.availability_in_store_by_book_titles)
        result2 = self.bookstore.receive_book("Book3", 1)
        self.assertEqual('2 copies of Book3 are available in the bookstore.', result2)
        self.assertEqual({'Book1': 2, 'Book2': 2, 'Book3': 2}, self.bookstore.availability_in_store_by_book_titles)

    def test_sale_EX1(self):
        # if the book is not available in the bookstore
        with self.assertRaises(Exception) as ex:
            self.bookstore.sell_book("None_Book", 2)
        self.assertEqual(f"Book None_Book doesn't exist!", str(ex.exception))

    def test_sale_EX2(self):
        # if there is not enough copies of that book to sell
        with self.assertRaises(Exception) as ex:
            self.bookstore.sell_book("Book1", 20)
        self.assertEqual(f"Book1 has not enough copies to sell. Left: 2", str(ex.exception))

    def test_sale_working(self):
        result = self.bookstore.sell_book("Book1", 1)
        self.assertEqual(f"Sold 1 copies of Book1", result)
        result_len = self.bookstore.__len__()
        self.assertEqual(3, result_len)
        result2 = self.bookstore.sell_book("Book2", 2)
        self.assertEqual("Sold 2 copies of Book2", result2)
# bqh zabravila tezi
        result_len2 = self.bookstore.__len__()
        self.assertEqual(1, result_len2)
        result3 = self.bookstore.total_sold_books
        self.assertEqual(3, result3)

    def test_str(self):
        result = self.bookstore.__str__()
        self.assertEqual(f"Total sold books: 0\n"
                         f"Current availability: 4\n"
                         f" - Book1: 2 copies\n"
                         f" - Book2: 2 copies", result)


if __name__ == "__main__":
    main()

