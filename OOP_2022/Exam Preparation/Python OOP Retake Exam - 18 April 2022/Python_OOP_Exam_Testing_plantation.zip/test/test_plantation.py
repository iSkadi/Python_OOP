from project.plantation import Plantation
from unittest import TestCase, main


class TestPlantation(TestCase):
    def setUp(self) -> None:
        self.plantation = Plantation(10)

    def test_init(self):

        self.assertEqual(10, self.plantation.size)
        self.assertEqual({}, self.plantation.plants)
        self.assertEqual([], self.plantation.workers)

    def test_size_error(self):
        size = -1
        with self.assertRaises(ValueError) as ve:
            result = self.plantation.size = size
        self.assertEqual("Size must be positive number!", str(ve.exception))

    def test_len(self):
        self.plantation.plants = {"Pesho": ['Rose', "Kola"], "Nadq": ['tomato', "Pine"]}
        result = self.plantation.__len__()
        self.assertEqual(4, result)

    def test_hire_worker_exeption(self):
        worker = "Pesho"
        self.plantation.hire_worker(worker)

        with self.assertRaises(ValueError) as ve:
            self.plantation.hire_worker("Pesho")
        self.assertEqual("Worker already hired!", str(ve.exception))


    def test_hire_worker_working(self):

        result = self.plantation.hire_worker("Nadq")
        self.assertEqual("Nadq successfully hired.", result)
        self.assertEqual(1, len(self.plantation.workers))



    def test_planting_worker_not_in_self_workers(self):
        worker = "Pesho"
        plant = "Rose"

        with self.assertRaises(ValueError) as ve:
            self.plantation.planting(worker, plant)
        self.assertEqual(f"Worker with name {worker} is not hired!", str(ve.exception))

    def test_the_plantation_is_full(self):
        worker = "Pesho"
        plant = "apple"
        self.plantation.size = 3
        self.plantation.hire_worker(worker)
        self.plantation.plants = {"Pesho": ['Rose', "Pine", "tomato"]}
        with self.assertRaises(ValueError) as ve:
            self.plantation.planting(worker, plant)
        self.assertEqual("The plantation is full!", str(ve.exception))
        self.assertEqual(self.plantation.size, self.plantation.__len__())

    def test_the_plantation_have_more_then_size(self):
        worker = "Pesho"
        plant = "apple"
        self.plantation.size = 2
        self.plantation.hire_worker(worker)
        self.plantation.plants = {"Pesho": ['Rose', "Pine", "tomato"]}
        with self.assertRaises(ValueError) as ve:
            self.plantation.planting(worker, plant)
        self.assertEqual("The plantation is full!", str(ve.exception))
        self.assertLessEqual(self.plantation.size, self.plantation.__len__())

    def test_planting_worker_plant_first(self):
        self.plantation.hire_worker("Pesho")
        result = self.plantation.planting("Pesho", "Rose")

        exe = f"Pesho planted it's first Rose."
        self.assertEqual(exe, result)
        self.assertEqual(["Rose"], self.plantation.plants["Pesho"])

    def test_planting_worker_plant(self):
        self.plantation.hire_worker("Pesho")
        self.plantation.planting("Pesho", "Apple")
        result = self.plantation.planting("Pesho", "Rose")

        exe = f"Pesho planted Rose."
        self.assertEqual(exe, result)
        self.assertEqual(["Apple", "Rose"], self.plantation.plants["Pesho"])





    def test_str(self):

        workers = ["Pesho", "Lili"]
        self.plantation.workers = workers
        plants = {"Pesho": ["Rose", "Pine"], "Lili": ["Apple"]}
        self.plantation.plants = plants


        result = self.plantation.__str__()
        exe = "Plantation size: 10\nPesho, Lili\nPesho planted: Rose, Pine\nLili planted: Apple"
        self.assertEqual(exe, result)

    def test_repr(self):

        workers = ["Pesho", "Lili"]
        self.plantation.workers = workers
        plants = {"Pesho": ["Rose", "Pine"], "Lili": ["Apple"]}
        self.plantation.plants = plants

        result = self.plantation.__repr__()
        exe = 'Size: 10\nWorkers: Pesho, Lili'
        self.assertEqual(exe, result)


if __name__ == "__main__":
    main()