from project.customer import Customer
from project.equipment import Equipment
from project.exercise_plan import ExercisePlan
from project.subscription import Subscription
from project.trainer import Trainer


class Gym:
    def __init__(self):
        self.customers = []
        self.trainers = []
        self.equipment = []
        self.plans = []
        self.subscriptions = []

    def __add(self, obj, list):
        if obj not in list:
            list.append(obj)
        return

    def add_customer(self, customer: Customer):
        self.__add(customer, self.customers)

    def add_trainer(self, trainer: Trainer):
        self.__add(trainer, self.trainers)

    def add_equipment(self, equipment: Equipment):
        self.__add(equipment, self.equipment)

    def add_plan(self, plan: ExercisePlan):
        self.__add(plan, self.plans)

    def add_subscription(self, subscription: Subscription):
        self.__add(subscription, self.subscriptions)

    def __find_by_id(self, entities, entity_id):
        for entity in entities:
            if entity.id == entity_id:
                return entity

    def subscription_info(self, subscription_id: int):
        subscription = self.__find_by_id(self.subscriptions, subscription_id)
        customer = self.__find_by_id(self.customers, subscription.customer_id)
        trainer = self.__find_by_id(self.trainers, subscription.trainer_id)
        plan = self.__find_by_id(self.plans, subscription.exercise_id)
        equipment = self.__find_by_id(self.equipment, plan.equipment_id)

        return repr(subscription) + "\n" + \
               repr(customer) + "\n" + \
               repr(trainer) + "\n" + \
               repr(equipment) + "\n" + \
               repr(plan)








