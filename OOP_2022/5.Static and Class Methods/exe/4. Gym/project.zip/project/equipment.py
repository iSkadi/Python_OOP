class Equipment:
    ID = 1

    def __init__(self, name):
        self.name = name
        self.id = self.get_next_id() # id има клас атрибут

    @staticmethod
    def get_next_id():
        new_id = Equipment.ID # текущата стойност на клас атрибута
        Equipment.ID += 1
        return new_id

    def __repr__(self):
        return f"Equipment <{self.id}> {self.name}"

