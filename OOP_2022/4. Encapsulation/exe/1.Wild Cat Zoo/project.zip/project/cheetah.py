from project.animal import Animal


class Cheetah(Animal):
    money_for_care = 60

    def __init__(self, name, age, gender):
        super().__init__(name, age, gender, self.money_for_care)
